#ifndef PRODUCTO_H_
#define PRODUCTO_H_

#define TIPO_PRODUCTO	1

typedef struct producto {
	long mtype;
	int numeroRandom;
} producto;

#endif /* PRODUCTO_H_ */
